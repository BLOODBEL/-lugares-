package com.dmgb.prollecto

import android.app.ActivityManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Toast
import com.dmgb.prollecto.databinding.ActivityMainBinding
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class MainActivity : AppCompatActivity() {

// autentificacion
    private lateinit var auth :FirebaseAuth


// pantalla xml

    private lateinit var binding: ActivityMainBinding


    override fun onCreate(savedInstanceState: Bundle?) {



        super.onCreate(savedInstanceState)
       binding = ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)

        //inicia la autentificacion
        FirebaseApp.initializeApp(this)
        auth = Firebase.auth

        // click de registro
        binding.btRegistro.setOnClickListener { registrar () }

        // clic loguin
        binding.btLoguin.setOnClickListener { loguin () }


    }

    private fun registrar () {
var email = binding.etCorreo.text.toString()
        var  clave: String = binding.etClave.text.toString()

        auth.createUserWithEmailAndPassword(email,clave)
            .addOnCompleteListener(this) { task -> if (
                task.isSuccessful
            ){
                val user = auth.currentUser
            }else{

                Toast.makeText(baseContext, "FALLO ${task.exception.toString()}", Toast.LENGTH_LONG).show()

            }

            }

    }
    private fun loguin () {


    }

}