package com.practicaexamen.repository

import androidx.lifecycle.LiveData
import com.practicaexamen.data.PlatilloDao
import com.practicaexamen.model.Platillo

class PlatilloRepository(private val platilloDao: PlatilloDao) {
    suspend fun guardarPlatillo(platillo: Platillo) {
        if (platillo.id == 0) {
            platilloDao.agregarPlatillo(platillo)
        } else {
            platilloDao.actualizarPlatillo(platillo)

        }
    }

    suspend fun eliminarPlatillo(platillo: Platillo) {
        platilloDao.eliminarPlatillo(platillo)

    }
        val obtenerPlatillos: LiveData<List<Platillo>> = platilloDao.getPlatillos()

}