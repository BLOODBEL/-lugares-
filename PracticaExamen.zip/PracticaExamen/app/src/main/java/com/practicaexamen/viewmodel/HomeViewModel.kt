package com.practicaexamen.viewmodel

import android.app.Application
import androidx.lifecycle.*
import androidx.room.Database
import com.practicaexamen.data.PlatilloDatabase
import com.practicaexamen.data.PlatilloDatabase.Companion.getDatabase
import com.practicaexamen.model.Platillo
import com.practicaexamen.repository.PlatilloRepository
import kotlinx.coroutines.launch

class HomeViewModel (application: Application) : AndroidViewModel(application) {

    private  val repository: PlatilloRepository
    val obtenerPlatillos: LiveData<List<Platillo>>

    init {
        val platilloDao =  PlatilloDatabase.getDatabase(application).platilloDao()
        repository = PlatilloRepository(platilloDao)
        obtenerPlatillos = repository.obtenerPlatillos
    }
    fun guardarLugar(platillo: Platillo){
        viewModelScope.launch { repository.guardarPlatillo(platillo) }
    }

    fun eliminarLugar(platillo: Platillo){
        viewModelScope.launch { repository.eliminarPlatillo(platillo) }
    }
}
