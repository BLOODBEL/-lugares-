package com.practicaexamen.data

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.practicaexamen.model.Platillo


@Database(entities = [Platillo::class],version = 1, exportSchema = false)
abstract class PlatilloDatabase : RoomDatabase() {
    abstract fun platilloDao(): PlatilloDao


    companion object {
        @Volatile
        private var INSTANCE: PlatilloDatabase? = null

        fun getDatabase(context: android.content.Context): PlatilloDatabase {
            val temp = INSTANCE
            if (temp != null) {
                return temp
            }
            synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    PlatilloDatabase::class.java,
                    "platillo_database").build()
                INSTANCE = instance
                return instance
            }

        }

    }
}