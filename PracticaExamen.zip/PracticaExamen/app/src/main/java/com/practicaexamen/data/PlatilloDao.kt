package com.practicaexamen.data

import androidx.lifecycle.LiveData
import androidx.room.*
import com.practicaexamen.model.Platillo


@Dao
interface PlatilloDao {
    @Query("SELECT * FROM PLATILLO")
    fun getPlatillos(): LiveData<List<Platillo>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun agregarPlatillo(platillo: Platillo)

    @Update(onConflict = OnConflictStrategy.IGNORE)
    suspend fun actualizarPlatillo(platillo: Platillo)

    @Delete
    suspend fun eliminarPlatillo(platillo: Platillo)
}