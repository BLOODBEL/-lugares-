package com.practicaexamen.model

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(tableName = "platillo")
data class Platillo(
    @PrimaryKey(autoGenerate = true)
    val id: Int,
    @ColumnInfo(name = "nombrePlatillo")
    val nombre: String,
    @ColumnInfo(name = "TipoPlatillo")
    val correo: String?,
    @ColumnInfo(name = "Ingredientes")
    val telefono: String?,
    @ColumnInfo(name = "web")
    val web: String?
): Parcelable