package com.practicaexamen

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import com.practicaexamen.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    //Definimos un objeto para acceder a la autenticación de Firebase
    private lateinit var auth: FirebaseAuth

    //Definimos un objeto para acceder a los elementos de la pantalla xml
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //Inicializar la autenticación
        FirebaseApp.initializeApp(this)
        auth = Firebase.auth

        //Definir el evento onClic del boton Register
        binding.btRegister.setOnClickListener { haceRegistro() }

        //Definir el evento onClic del boton Login
        binding.btLogin.setOnClickListener { haceLogin() }

    }

    private fun haceRegistro() {
        val email = binding.etCorreo.text.toString()
        val clave: String = binding.etClave.text.toString()

        //registro de usuario
        auth.createUserWithEmailAndPassword(email, clave)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    val user = auth.currentUser
                    cargarPantalla(user)
                } else {
                    Toast.makeText(
                        baseContext,
                        "Fallo ${task.exception.toString()}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
    }

    private fun cargarPantalla(user: FirebaseUser?) {
        if (user != null) {
            val intent = Intent(this, Principal::class.java)
            startActivity(Intent())
        }

    }

    private fun haceLogin() {
        val email = binding.etCorreo.text.toString()
        val clave: String = binding.etClave.text.toString()

        //login
        auth.signInWithEmailAndPassword(email, clave)
            .addOnCompleteListener { result ->
                if (result.isSuccessful) {
                    val user = auth.currentUser
                    cargarPantalla(user)
                } else {
                    Toast.makeText(baseContext, getText(R.string.noLogin), Toast.LENGTH_LONG).show()
                }
            }
    }
//una vez autenticado no pide mas a menos que se cierre la sesion
    override fun onStart() {
        super.onStart()
        val user = auth.currentUser
        cargarPantalla(user)
    }
}