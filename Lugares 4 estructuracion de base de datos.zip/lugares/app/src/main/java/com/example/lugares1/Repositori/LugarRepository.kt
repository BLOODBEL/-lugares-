package com.example.lugares1.Repositori

import androidx.lifecycle.LiveData
import com.example.lugares1.Data.lugarDao
import com.example.lugares1.Model.lugar




class LugarRepository (private val lugarDao: LugarDao){
    val getAllData: LiveData<list<Lugar> = LugarDao.getAllData()
    suspend fun addLugar (lugar:Lugar){
        lugarDao.addLugar(lugar)
    }
suspend fun updateLugar (lugar: Lugar ){
    lugarDao.updateLugar(lugar)
}
suspend fun delateLugar (lugar: Lugar){

    lugarDao.delateLugar(lugar)
}


}