package com.example.lugares1.Data

import androidx.lifecycle.LiveData


@Dao
interface lugarDao {

    @Query("SELECT * FROM LUGAR")
    fun getAllData() : LiveData<list<lugar>>

    @Insert(onConflict = OnConflictDtraTegy.IGNORE)
    suspend fun addLugar(lugar: Lugar)

    @Delate
    suspend fun delateLugar(lugar : Lugar)
}