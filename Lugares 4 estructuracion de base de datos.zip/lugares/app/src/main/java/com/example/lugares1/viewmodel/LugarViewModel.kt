package com.example.lugares1.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import android.app.Application
import androidx.lifecycle.*
import com.example.lugares.data.LugarDatabase
import com.example.lugares.model.Lugar
import com.example.lugares.repository.LugarRepository
import com.example.lugares1.Repositori.LugarRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch




class LugarViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "This is home Fragment"
    }
    val text: LiveData<String> = _text

    private val repository:LugarRepository
    int{
        val lugarDao=LugarDatabase.getDatabase(application).lugarDao()
        repository= LugarRepository(lugarDao)
        getAllData = repository.getAllData

    }
    fun addlugar (lugar:Lugar ){
        viewModelScope.launch (Dispatchers.IO){repository.addLugar((lugar))}

    }
    fun updateLugar (lugar:Lugar ){
        viewModelScope.launch  (Dispatchers.IO){repository.updateLugar((lugar))}
    }
    fun delateLugar (lugar: Lugar ){
        viewModelScope.launch  (Dispatchers.IO){repository.updateLugar((lugar))}
    }



}