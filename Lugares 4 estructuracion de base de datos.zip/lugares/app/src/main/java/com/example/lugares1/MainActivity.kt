package com.example.lugares1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.lugares1.databinding.ActivityMainBinding
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import java.security.Principal

class MainActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var binding: ActivityMainBinding




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        FirebaseApp.initializeApp(this)
        auth = Firebase.auth

        binding.btLogin.setOnClickListener {
            haceLogin();

        }
        binding.btRegister.setOnClickListener {
            haceRegister();

        }
    }

    private fun haceRegister() {
        var email = binding.etEmail.text.toString()
        var clave = binding.etClave.text.toString()
        auth.createUserWithEmailAndPassword(email,clave)
            .addOnCompleteListener(this){  task ->
                if (task.isSuccessful){
                     log.d("creando usuario", "registrando")
                     val user = auth.currentUser
                    actuliza(user)

                } else {
                    log.d("creando usuario", "Fallo")
                   Toast.makeText(baseContext,"fallo",Toast.LENGTH_LONG).show()
                    actuliza(null)
                }

            }
    }
   private fun actuliza (user: FirebaseUser){
  if (user¡= null ){
           val intenr = intent(this, Principal::class, java)
    startActivity(intent)


       }

   }
}

public override fun onStart(){
    super.onStart()
    val usuario = auth.currentUser
    actualiza(usuario)
}


    private fun haceLogin() {
        var email = binding.etEmail.text.toString()
        var clave = binding.etClave.text.toString()

        auth.signInWithEmailAndPassword(email,clave)
            .addOnCompleteListener(this){  task ->
                if (task.isSuccessful){
                    log.d("Autenticando", "Autenticado")
                    val user = auth.currentUser
                    actuliza(user)

                } else {
                    log.d("Autenticando", "Fallo")
                    Toast.makeText(baseContext,"fallo",Toast.LENGTH_LONG).show()
                    actuliza(null)
                }

            }


}